package com.controller;

import java.util.Scanner;

public class FarmerOperation {

	Scanner sc=new Scanner(System.in);
	MethodClass mc=new MethodClass();
	public void createFarm() {
		boolean b=true;
		while(b) {
		System.out.println("1.buy farm");
		System.out.println("2.view all farm");
		System.out.println("3.sell farm");
		System.out.println("4.logout");
		System.out.println();
		
		System.out.println("enter the choice");
		int choice=sc.nextInt();
		switch(choice) {
		case 1:{
			mc.buyFarm();
		}
		break;
		case 2:{
			mc.viewFarm();
		}
		break;
		case 3:{
			mc.sellFarm();
		}
		break;
		case 4:{
			b=false;
		}
		break;
		default :{
			System.out.println("enter valid choice");
		}
		}
		}
	}
}

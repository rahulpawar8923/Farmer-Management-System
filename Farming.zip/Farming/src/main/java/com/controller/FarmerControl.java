package com.controller;

import java.util.Scanner;

public class FarmerControl {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		MethodClass mc = new MethodClass();
		
		boolean b=true;
		while(b) {
			System.out.println("1.create account");
			System.out.println("2.login");
			System.out.println("3.close");
			System.out.println("===================");
			
			System.out.println("enter the choice");
			int choice=sc.nextInt();
		switch(choice) {
		
		case 1:{
			mc.createAccount();
		}
		break;
		case 2:{
			mc.login();
		}
		break;
		case 3:{
			System.out.println("thank you");
			b=false;
		}
		break;
		default :{
			System.out.println("enter valid choice");
			System.out.println();
		}
		break;
		}
		}
	}
}

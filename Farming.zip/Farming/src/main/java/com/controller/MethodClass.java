package com.controller;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.dto.entity.Farm;
import com.dto.entity.Farmer;

public class MethodClass {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("rahul");
	EntityManager em=emf.createEntityManager();
	EntityTransaction et=em.getTransaction();
	Scanner sc=new Scanner(System.in);
	
	public void createAccount() {
		System.out.println("enter name");
		String name=sc.nextLine();
		System.out.println("enter email");
		String email=sc.next();
		System.out.println("enter password");
		String password=sc.next();
		System.out.println("enter mobile number");
		long mobilenumber=sc.nextLong();
		
		Farmer farmer = new Farmer();
		farmer.setName(name);
		farmer.setEmail(email);
		farmer.setPassword(password);
		farmer.setMobilenumber(mobilenumber);
		
		et.begin();
		em.persist(farmer);
		et.commit();
		
		System.out.println("farmer account created");
		System.out.println();
		
	}
	public void login() {
		System.out.println("enter email");
		String email=sc.next();
		System.out.println("enter password");
		String password=sc.next();
		
		Query query=em.createQuery("select a from Farmer a where a.email=?1 and a.password=?2");
		query.setParameter(1, email);
		query.setParameter(2, password);
		List<Farmer> farmer=query.getResultList();
		if(farmer.size()>0) {
			System.out.println("login success");
			System.out.println();
			
			FarmerOperation fo = new FarmerOperation();
			fo.createFarm();
		}
		else {
			System.out.println("check email and password");
			System.out.println();
		}
	}
	public void buyFarm() {
		
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter health");
		String health=sc.next();
		System.out.println("enter age");
		int age=sc.nextInt();
		System.out.println("enter weight");
		double weight=sc.nextDouble();
		System.out.println("enter disease");
		String disease=sc.next();
		
		Farm farm=new Farm();
		farm.setId(id);
		farm.setName(name);
		farm.setHealth(health);
		farm.setAge(age);
		farm.setWeight(weight);
		farm.setDisease(disease);
		
		et.begin();
		em.persist(farm);
		et.commit();
		
		System.out.println("farm created");
		System.out.println();
	}
	public void viewFarm() {
		
		Query query = em.createQuery("select a from Farm a");
		List<Farm> farm = query.getResultList();
		if(farm.size()>0) {
			for(Farm f:farm) {
				System.out.println("Id:      "+f.getId());
				System.out.println("Name:    "+f.getName());
				System.out.println("Health:  "+f.getHealth());
				System.out.println("Age:     "+f.getAge());
				System.out.println("Weight:  "+f.getWeight());
				System.out.println("Disease: "+f.getDisease());
				System.out.println("=============================");
			}
		}
		else {
			System.out.println("farm not created");
			System.out.println();
		}
		
	}
	public void sellFarm() {
		System.out.println("enter the id to sell");
		int id=sc.nextInt();
		
		Farm farm = em.find(Farm.class, id);
		if(farm!=null) {
		et.begin();
		em.remove(farm);
		et.commit();
		
		System.out.println("farm sell successfully");
		System.out.println();
		}
		else {
			System.out.println("not found");
			System.out.println();
		}
	}
}
